package javabeat.net.spring.model;

public class Company {
	private String ceos;
	private String companies;
	public String getCeos() {
		return ceos;
	}
	public void setCeos(String ceos) {
		this.ceos = ceos;
	}
	public String getCompanies() {
		return companies;
	}
	public void setCompanies(String companies) {
		this.companies = companies;
	}
}
